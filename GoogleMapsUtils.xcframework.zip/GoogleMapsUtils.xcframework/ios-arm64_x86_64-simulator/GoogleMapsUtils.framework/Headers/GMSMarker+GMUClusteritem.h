//
//  NSObject+GMSMarker_GMUClusteritem.h
//  DevApp
//
//  Created by Alex Muramoto on 5/7/20.
//  Copyright © 2020 Google. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GoogleMaps/GoogleMaps.h>
#import "GMUClusterItem.h"

@interface GMSMarker (GMSMarker_GMUClusteritem) <GMUClusterItem>

@end
